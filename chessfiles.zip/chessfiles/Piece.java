import java.awt.*;
import java.util.*;

public abstract class Piece
{
	//the board this piece is on
	private Board board;

	//the location of this piece on the board
	private Location location;

	//the color of the piece
	private Color color;

	//the file used to display this piece
	private String imageFileName;

	//the approximate value of this piece in a game of chess
	private int value;

	//the number of times this piece has moved
	private int moveCount;

	//constructs a new Piece with the given attributes.
	public Piece(Color col, String fileName, int val)
	{
		color = col;
		imageFileName = fileName;
		value = val;
	}

	//returns the board this piece is on
	public Board getBoard()
	{
		return board;
	}

	//returns the location of this piece on the board
	public Location getLocation()
	{
		return location;
	}

	//returns the color of this piece
	public Color getColor()
	{
		return color;
	}

	//returns the name of the file used to display this piece
	public String getImageFileName()
	{
		return imageFileName;
	}

	//returns a number representing the relative value of this piece
	public int getValue()
	{
		return value;
	}

	public boolean hasMoved()
	{
		return moveCount > 0;
	}

	public void recordMove()
	{
		moveCount++;
	}

	public void undoRecordedMove()
	{
		if (moveCount > 0)
			moveCount--;
	}

    /**
     * Puts this piece into a board. If there is another piece at the given
     * location, it is removed. <br />
     * Precondition: (1) This piece is not contained in a grid (2)
     * <code>loc</code> is valid in <code>gr</code>
     * @param brd the board into which this piece should be placed
     * @param loc the location into which the piece should be placed
     */
    public void putSelfInGrid(Board brd, Location loc)
    {
        if (board != null)
            throw new IllegalStateException(
                    "This piece is already contained in a board.");

        Piece piece = brd.get(loc);
        if (piece != null)
            piece.removeSelfFromGrid();
        brd.put(loc, this);
        board = brd;
        location = loc;
    }

    /**
     * Removes this piece from its board. <br />
     * Precondition: This piece is contained in a board
     */
    public void removeSelfFromGrid()
    {
        if (board == null)
            throw new IllegalStateException(
                    "This piece is not contained in a board.");
        if (board.get(location) != this)
            throw new IllegalStateException(
                    "The board contains a different piece at location "
                            + location + ".");

        board.remove(location);
        board = null;
        location = null;
    }

    /**
     * Moves this piece to a new location. If there is another piece at the
     * given location, it is removed. <br />
     * Precondition: (1) This piece is contained in a grid (2)
     * <code>newLocation</code> is valid in the grid of this piece
     * @param newLocation the new location
     */
    public void moveTo(Location newLocation)
    {
        if (board == null)
            throw new IllegalStateException("This piece is not on a board.");
        if (board.get(location) != this)
            throw new IllegalStateException(
                    "The board contains a different piece at location "
                            + location + ".");
        if (!board.isValid(newLocation))
            throw new IllegalArgumentException("Location " + newLocation
                    + " is not valid.");

        if (newLocation.equals(location))
            return;
        board.remove(location);
        Piece other = board.get(newLocation);
        if (other != null)
            other.removeSelfFromGrid();
        location = newLocation;
        board.put(location, this);
    }

	// Returns whether the given location is on the board and can be occupied by this piece.
	public boolean isValidDestination(Location dest)
	{
		if (board == null || !board.isValid(dest))
			return false;

		Piece piece = board.get(dest);
		return piece == null || !piece.getColor().equals(color);
	}

	// Adds each reachable location in the given direction until the board edge or a blocking piece.
	public void sweep(ArrayList<Location> dests, int direction)
	{
		if (board == null || location == null)
			return;

		Location next = location.getAdjacentLocation(direction);
		while (board.isValid(next))
		{
			if (!isValidDestination(next))
				return;

			dests.add(next);
			if (board.get(next) != null)
				return;

			next = next.getAdjacentLocation(direction);
		}
	}

	public abstract ArrayList<Location> destinations();

	public ArrayList<Location> attackLocations()
	{
		return destinations();
	}

	public String toString()
	{
		return getClass().getSimpleName() + " " + color + " at " + location;
	}
}
